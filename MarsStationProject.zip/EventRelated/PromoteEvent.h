//
// Created by raspberry on 2021-01-10.
//

#ifndef MARSSTATIONPROJECT_PROMOTEEVENT_H
#define MARSSTATIONPROJECT_PROMOTEEVENT_H
#include "Event.h"

class PromoteEvent: public Event
{
public:
    PromoteEvent(int ED, int ID);
    void Print() override;


};


#endif //MARSSTATIONPROJECT_PROMOTEEVENT_H

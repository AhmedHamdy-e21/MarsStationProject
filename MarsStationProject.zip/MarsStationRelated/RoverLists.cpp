//
// Created by raspberry on 2021-01-10.
//

#include "RoverLists.h"
#include "../DataStructure/Queue/LinkedQueue.cpp"
const LinkedQueue<EmergencyRover *> &RoverLists::getAvailableEmergencyRovers() const {
    return AvailableEmergencyRovers;
}

const LinkedQueue<PolarRover *> &RoverLists::getAvailablePolarRovers() const {
    return AvailablePolarRovers;
}

const LinkedQueue<MountainousRover *> &RoverLists::getAvailableMountainousRovers() const {
    return AvailableMountainousRovers;
}

int RoverLists::getNoOfAvailableEmergencyRovers() const {
    return AvailableEmergencyRovers.getSize();
}

int RoverLists::getNoOfAvailablePolarRovers() const {
    return AvailablePolarRovers.getSize();
}

int RoverLists::getNoOfAvailableMountainousRovers() const {
    return AvailableMountainousRovers.getSize();
}

 LinkedListMissions<EmergencyRover *> &RoverLists::getInMissionEmergencyRovers()  {
    return InMissionEmergencyRovers;
}

 LinkedListMissions<PolarRover *> &RoverLists::getInMissionPolarRovers()  {
    return InMissionPolarRovers;
}

 LinkedListMissions<MountainousRover *> &RoverLists::getInMissionMountainousRovers()  {
    return InMissionMountainousRovers;
}

int RoverLists::getNoOfInMissionEmergencyRovers() const {
    return InMissionEmergencyRovers.getCount();
}

int RoverLists::getNoOfInMissionPolarRovers() const {
    return InMissionPolarRovers.getCount();
}

int RoverLists::getNoOfInMissionMountainousRovers() const {
    return InMissionMountainousRovers.getCount();
}

const LinkedListMissions<EmergencyRover *> &RoverLists::getInCheckupEmergencyRovers() const {
    return InCheckupEmergencyRovers;
}

const LinkedListMissions<PolarRover *> &RoverLists::getInCheckupPolarRovers() const {
    return InCheckupPolarRovers;
}

const LinkedListMissions<MountainousRover *> &RoverLists::getInCheckupMountainousRovers() const {
    return InCheckupMountainousRovers;
}

int RoverLists::getNoOfInCheckupEmergencyRovers() const {
    return InCheckupEmergencyRovers.getCount();
}

int RoverLists::getNoOfInCheckupPolarRovers() const {
    return InCheckupPolarRovers.getCount();
}

int RoverLists::getNoOfInCheckupMountainousRovers() const {
    return InCheckupMountainousRovers.getCount();
}

void RoverLists::addAvailableEmergencyRover(EmergencyRover *ER)
{
    AvailableEmergencyRovers.enqueue(ER);
    AvailableEmergencyRoversIDs.push_back(ER->getID());
}



void RoverLists::addAvailablePolarRover(PolarRover *PR)
{
    AvailablePolarRovers.enqueue(PR);
    AvailablePolarRoversIDs.push_back(PR->getID());
}


void RoverLists::addAvailableMountainousRover(MountainousRover *ER)
{
    AvailableMountainousRovers.enqueue(ER);
    AvailableMountainousRoversIDs.push_back(ER->getID());


}

MountainousRover *RoverLists::getAvailableMountainousRover()
{
    bool isAvailable;
    MountainousRover* M;
    isAvailable=AvailableMountainousRovers.dequeue(M);
    int ID=M->getID();
    if(isAvailable)
    {
        AvailableMountainousRoversIDs.erase(std::remove(AvailableMountainousRoversIDs.begin(), AvailableMountainousRoversIDs.end(), ID), AvailableMountainousRoversIDs.end());
        return M;
    }
    return nullptr;
}

PolarRover *RoverLists::getAvailablePolarRover()
{
    bool isAvailable;
    PolarRover* M;
    isAvailable=AvailablePolarRovers.dequeue(M);
    int ID=M->getID();
    if(isAvailable)
    { AvailablePolarRoversIDs.erase(std::remove(AvailablePolarRoversIDs.begin(), AvailablePolarRoversIDs.end(), ID), AvailablePolarRoversIDs.end());
        return M;
    }
    return nullptr;
}

EmergencyRover *RoverLists::getAvailableEmergencyRover()
{
    bool isAvailable;
    EmergencyRover* M;
    isAvailable=AvailableEmergencyRovers.dequeue(M);
    int ID=M->getID();
    if(isAvailable)
    {
        AvailableEmergencyRoversIDs.erase(std::remove(AvailableEmergencyRoversIDs.begin(), AvailableEmergencyRoversIDs.end(), ID), AvailableEmergencyRoversIDs.end());
        return M;
    }
    return nullptr;
}

void RoverLists::addInMissionEmergencyRover(EmergencyRover *ER)
{
    InMissionEmergencyRovers.InsertBeg(ER);
}

EmergencyRover *RoverLists::getInMissionEmergencyRover()
{
    EmergencyRover * ReturnedObj=(InMissionEmergencyRovers.DeleteFirst());
    return ReturnedObj;
}

void RoverLists::addInCheckupEmergencyRover(EmergencyRover *ER)
{
   InCheckupEmergencyRovers.InsertBeg(ER);


}

EmergencyRover *RoverLists::getInCheckupEmergencyRover() {
    EmergencyRover * ReturnedObj=(InCheckupEmergencyRovers.DeleteFirst());
    return ReturnedObj;
}

void RoverLists::addInMissionPolarRover(PolarRover *PR)
{
    InMissionPolarRovers.InsertBeg(PR);

}

PolarRover *RoverLists::getInMissionPolarRover() {
    PolarRover * ReturnedObj=(InMissionPolarRovers.DeleteFirst());
    return ReturnedObj;
}

void RoverLists::addInCheckupPolarRover(PolarRover *PR)
{
    InCheckupPolarRovers.InsertBeg(PR);


}

PolarRover *RoverLists::getInCheckupPolarRover() {
    PolarRover * ReturnedObj=(InCheckupPolarRovers.DeleteFirst());
    return ReturnedObj;
}

void RoverLists::addInMissionMountainousRover(MountainousRover *ER)
{
    InMissionMountainousRovers.InsertBeg(ER);

}

MountainousRover *RoverLists::getInMissionMountainousRover() {
    MountainousRover * ReturnedObj=(InMissionMountainousRovers.DeleteFirst());
    return ReturnedObj;
}

void RoverLists::addInCheckupMountainousRover(MountainousRover *ER)
{
    InCheckupMountainousRovers.InsertBeg(ER);
}

MountainousRover *RoverLists::getInCheckupMountainousRover() {
    MountainousRover * ReturnedObj=(InCheckupMountainousRovers.DeleteFirst());
    return ReturnedObj;
}

void RoverLists::addMultipleAvailableEmergencyRovers(int NumberOfEmergencyRovers,int Speed, int CheckupDuration, int NoCheckupMissions,int ID)
{
     int i=0;
     int n=(getNoOfAvailablePolarRovers()+getNoOfAvailableMountainousRovers());
    for ( i = 0; i <NumberOfEmergencyRovers ; ++i)
    {
        EmergencyRover* ER=new EmergencyRover(Speed,CheckupDuration,NoCheckupMissions,i+n);
        addAvailableEmergencyRover(ER);
    }
//    cout<< "\nAdded "<<AvailableEmergencyRovers.getSize()<<" Emergency Rovers to be Available\n";
//    EmergencyRover* MR;
//    cout<< "My information is: ";AvailableEmergencyRovers.peek(MR);
//    MR->Print();

}

void RoverLists::addMultipleAvailablePolarRovers(int NumberOfPolarRovers,int Speed, int CheckupDuration, int NoCheckupMissions,int ID)
{
    int i=0;
    int n=getNoOfAvailableMountainousRovers(); // This is to generate ids for rovers

    for ( i = 0; i <NumberOfPolarRovers ; ++i)
    {
        PolarRover* PR=new PolarRover(Speed,CheckupDuration,NoCheckupMissions,i+n);
        addAvailablePolarRover(PR);
    }
//    cout<< "\nAdded "<<AvailablePolarRovers.getSize()<<" Polar Rovers to be Available\n";
//    PolarRover* MR;
//    cout<< "My information is: ";AvailablePolarRovers.peek(MR);
//    MR->Print();
}

void RoverLists::addMultipleAvailableMountainousRovers(int NumberOfMountainousRovers,int Speed, int CheckupDuration, int NoCheckupMissions,int ID)
{
    int i=0;
    for ( i = 0; i <NumberOfMountainousRovers ; ++i)
    {
        MountainousRover* MR=new MountainousRover(Speed,CheckupDuration,NoCheckupMissions, i);
        addAvailableMountainousRover(MR);

    }
//    cout<< "\nAdded "<<AvailableMountainousRovers.getSize()<<" Mountainous Rovers to be Available\n";
//    MountainousRover* MR;
//
//    cout<< "My information is: ";AvailableMountainousRovers.peek(MR);
//    MR->Print();
}

EmergencyRover *RoverLists::peekAvailableEmergencyRover()
{
    EmergencyRover* ER;
    AvailableEmergencyRovers.peek(ER);
    return ER;
}

PolarRover *RoverLists::peekAvailablePolarRover()
{
    PolarRover* PR;
    AvailablePolarRovers.peek(PR);
    return PR;
}

MountainousRover *RoverLists::peekAvailableMountainousRover()
{
    MountainousRover* MR;
    AvailableMountainousRovers.peek(MR);
    return MR;
}

void RoverLists::deleteInCheckupEmergencyRover(int ID)
{
    InCheckupEmergencyRovers.DeleteNode(ID);
}

void RoverLists::deleteInCheckupPolarRover(int ID)
{
    InCheckupPolarRovers.DeleteNode(ID);
}

void RoverLists::deleteInCheckupMountainousRover(int ID)
{
    InCheckupMountainousRovers.DeleteNode(ID);


}

void RoverLists::deleteInMissionPolarRover(int ID) {
    InMissionPolarRovers.DeleteNode(ID);

}

void RoverLists::deleteInMissionMountainousRover(int ID)
{
    InMissionMountainousRovers.DeleteNode(ID);

}

void RoverLists::deleteInMissionEmergencyRover(int ID)
{
    InMissionEmergencyRovers.DeleteNode(ID);
}

const vector<int> &RoverLists::getAvailableMountainousRoversIDs() const {
    return AvailableMountainousRoversIDs;
}

void RoverLists::setAvailableMountainousRoversIDs(const vector<int> &availableMountainousRoversIDs) {
    AvailableMountainousRoversIDs = availableMountainousRoversIDs;
}

const vector<int> &RoverLists::getAvailablePolarRoversIDs() const {
    return AvailablePolarRoversIDs;
}

void RoverLists::setAvailablePolarRoversIDs(const vector<int> &availablePolarRoversIDs) {
    AvailablePolarRoversIDs = availablePolarRoversIDs;
}

const vector<int> &RoverLists::getAvailableEmergencyRoversIDs() const {
    return AvailableEmergencyRoversIDs;
}

void RoverLists::setAvailableEmergencyRoversIDs(const vector<int> &availableEmergencyRoversIDs) {
    AvailableEmergencyRoversIDs = availableEmergencyRoversIDs;
}


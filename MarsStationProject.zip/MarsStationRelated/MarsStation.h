//
// Created by raspberry on 2021-01-10.
//
#ifndef MARSSTATIONPROJECT_MARSSTATION_H
#define MARSSTATIONPROJECT_MARSSTATION_H
#include  "../MarsStationRelated/MissionLists.h"
#include  "../MarsStationRelated/RoverLists.h"
#include "UIClass.h"
#include "EventLists.h"
#include <fstream>
#include <string>
#include "UIClass.h"
#include <map>
#include <vector>
#include <algorithm>
class MarsStation
{
private:
    MissionLists MLs;
    RoverLists RLs;
    EventLists EVs;
    UIClass UIclass;
    // I need to map the mission ids to the rovers id using map simply
    map<int, int> IDDictionary;
    int AutoP;
    int CurrentDay;


//    map<string, int> CompletedPolarMissionhistory;
//    map<string, int> CompletedEmergencyMissionhistory;
//    map<string, int> CompletedMountainousMissionhistory;



//

public:


    void writeSampleFile();



    void insertIDPair(int MissionID,int RoverID);
    void eraseIDPair(int MissionID);


    int getCurrentDay() const;

    int iterateCurrentDay();

    void setCurrentDay(int currentDay);
    int returnRoverID(int MissionID);

     MissionLists &getMLs() ;

     RoverLists &getRLs() ;

     EventLists &getEVs() ;

    void setAutoP(int autoP);

    int getAutoP() const;
    // I need to keep the history of something right here. or in the Mission itself. Anywhere but just remember to do so.
    // Also don't forget to add the signify() function in mission in order to increase the significance of the emergency mission.
    // Then ISA, you're to implement the assign fuctions.

    MarsStation();
    void loadFile(string FileName);


    ///// These assignment functions are working awesome after reviewing their performance.
    //// Also they are managed by queue which is to some extent straightforward. So I don't have to worry about them
    bool assignMountainousMission(int & ID);
    bool assignPolarMission(int &ID);
    bool assignEmergencyMission(int& ID);
    bool assignTodaysMission(int CurrentDay);

    ///////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////Get Any kind of Data from here
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// The data is passed by value in order to copy it and get the availble rovers ids
    void AvailableRoversIDs(vector<int> &AvailableMountainousRoversIDs, vector<int> &AvailablePolarRoversIDs,
                            vector<int> &AvailableEmergencyRoversIDs, LinkedQueue<MountainousRover *> MRQueue,
                            LinkedQueue<PolarRover *> PRQueue, LinkedQueue<EmergencyRover *> ERQueue);




    void WaitingMissionsIDs(vector<int> &AvailableMountainousMissionsIDs, vector<int> &AvailablePolarMissionsIDs,
                            vector<int> &AvailableEmergencyMissionsIDs, LinkedListMissions<MountainousMission *> MMList,
                            LinkedQueue<PolarMission *> PMQueue, MaxHeap<EmergencyMission *> EMHeap);

    void InExecutionMissionsIDs(vector<int> &InExecutionMountainousMissionsIDs,
                                vector<int> &InExecutionPolarMissionsIDs,
                                vector<int> &InExecutionEmergencyMissionsIDs,
                                LinkedListMissions<MountainousMission *>* MMList, LinkedListMissions<PolarMission *>* PMList,
                                LinkedListMissions<EmergencyMission *>* EMList);

    void CompletedMissionsIDs(vector<int> &CompletedMountainousMissionsIDs, vector<int> &CompletedPolarMissionsIDs,
                              vector<int> &CompletedEmergencyMissionsIDs, LinkedListMissions<MountainousMission *>* MMList,LinkedListMissions<PolarMission *>* PMList, LinkedListMissions<EmergencyMission *>* EMList);


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////Simulator Related
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





    //// Check for the completed missions and then transfer them to the completed list.
    MountainousRover* CompletedMountainous(MountainousMission* MM,int CurrentDay);
    PolarRover* CompletedPolar(PolarMission* PM,int CurrentDay);
    EmergencyRover* CompletedEmergency(EmergencyMission* EM,int CurrentDay);
    ///// I need to implement a function that transfer Rovers from Inmission to either Checkup or Avaialble


    bool isCompletedToday(int CurrentDay);

    // Think how you will know whether it's completed or not.
    bool cancelTodaysMission(int CurrentDay);
    bool promoteTodaysMission(int CurrentDay);
    void simulate(int CurrentDay);

//////////////////////////////////////////////////////////////////////////////////////////
//// Now I need to get the rovers from being in mission to either available or In checkup
//// Then After the Checkup I need to add them to available.
    bool transferInMissionMountainousRover( MountainousRover* MR);
    bool transferInMissionPolarRover(PolarRover* PR);
    bool transferInMissionEmergencyRover(EmergencyRover* EM);



    ~MarsStation();


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////UNDER CONSTRUCTION X
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    bool doneCheckup();


    void printInteractiveMode(int CurrentDay); /// This print correctly ISA.




};
#endif //MARSSTATIONPROJECT_MARSSTATION_H

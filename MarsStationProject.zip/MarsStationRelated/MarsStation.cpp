//
// Created by raspberry on 2021-01-10.
//

#include "MarsStation.h"
void MarsStation::loadFile(string FileName)
{
    ifstream inputFile;

    inputFile.open(FileName);
    // Check for Error:
    if (inputFile.fail()) {
        cerr << "Error opening the file" << endl;
        exit(1);
    }
//    else
//    {
////        cout << "I open the file now" << endl;
//    }
    int M, P, E, SM, SP, SE, N, CM, CP, CE, AutoP, EV, ED, ID, TLOC, MIDUR, SIG;
    char F, TYP;
    inputFile >> M;
    inputFile >> P;
    inputFile >> E; //number of events
    inputFile >> SM;
    inputFile >> SP;
    inputFile >> SE;
    inputFile >> N;
    inputFile >> CM;
    inputFile >> CP;
    inputFile >> CE;
    inputFile >> AutoP;
    setAutoP(AutoP);


    RLs.addMultipleAvailableMountainousRovers(M,SM,CM,N);

    RLs.addMultipleAvailablePolarRovers(P,SP,CP,N);

    RLs.addMultipleAvailableEmergencyRovers(E,SE,CE,N);

    // This is to initialize the Available Emergency Rovers.
    inputFile >> EV;
    for (int j = 0; j < EV; j++)
    {
        string type;
        inputFile >> type;
        if (type == "F")
        {
            inputFile >> TYP;
            inputFile >> ED;
            inputFile >> ID;
            inputFile >> TLOC;
            inputFile >> MIDUR;
            inputFile >> SIG;
            EVs.addFormulationEvent(ID,ED,TYP,TLOC,MIDUR,SIG); // It's loading correctly, I check it in the debugging mode
        }
        else if (type == "X")
        {
            inputFile >> ED;
            inputFile >> ID;
            EVs.addCancellationEvent(ID,ED);
        }
        else if (type == "P")
        {
            inputFile >> ED;
            inputFile >> ID;
            EVs.addPromotionEvent(ED,ID);
        }
    }
    inputFile.close();
}






MarsStation::MarsStation() {
//    this->IDDictionary.insert({-1,-1});
}

MarsStation::~MarsStation() {
}

bool MarsStation::assignMountainousMission(int & ID)
{
    if(RLs.peekAvailableMountainousRover())
    {
        MountainousRover* MR;
        MR=RLs.getAvailableMountainousRover();
        RLs.addInMissionMountainousRover(MR);
        ID= MR->getID();
        return true;
    }
    else if(RLs.peekAvailableEmergencyRover())
    { // add to the Emergency if there isn't Mountainous one
        EmergencyRover* ER;
        ER=RLs.getAvailableEmergencyRover();
        RLs.addInMissionEmergencyRover(ER);
        ID= ER->getID();
        return true;
    }
    else return false;
}

//// So the assign polar just take a mission and assign it if there is an available rovers.
//// The other assignment large function will check the type of events and create the corresponding missions.
//// Then just call the subroutine assign to switch the status.

bool MarsStation::assignPolarMission(int &ID)
{
    // peak function is redundut because the get either return a rover or null. So I don't need to peak rover.
    // But I'll continue and check like make it as if isAvailable function.
    if (RLs.peekAvailablePolarRover())
    {
        // So there is a polar rover available.
        PolarRover* PR;
        PR=RLs.getAvailablePolarRover();
        RLs.addInMissionPolarRover(PR);
        ID= PR->getID();
//        cout<<"ID is"<<ID;
        return true;
    }
    else return false;
}

// If smaller than or equal the current day
bool MarsStation::assignTodaysMission(int CurrentDay)
{
    //// First check will be on the Emergency
    // Then Mountainous.
    // Then Polar.
    // So the assign function must be generic for all types
    // It'll be large and huge.
    // So I need to think how I can discretize it in order to trace errors later.
    // Firstly peek to check whether there is Polar mission today

//// //// There should be a loop here not just if

//// The emergency mission need to be loaded firstly in this day. In order to be ordered in the heap
if (!EVs.getFormulationEventList().isEmpty()) {
    while (EVs.peekFormulationEvent()->getEventDay() == CurrentDay ||
           EVs.peekFormulationEvent()->getEventDay() < CurrentDay) {

        FormulationEvent *FE;
        FE = EVs.getFormulationEvent();

        if (FE->getMissionType() == 'E') {
            // add emergency mission. first. Because you are not sure whether there is an available rover or not
            // I need a constructor that initialized by the mission.

            int MissionID;
            int RoverID;
            EmergencyMission *EM = new EmergencyMission(FE, CurrentDay);
            MLs.addEmergencyMission(EM);
            // I can recurrsively call the add here
            assignTodaysMission(
                    CurrentDay); //// This recurrsive call should add all emergency mission first then It'll proceed.
            //// But I don't know how it'll perform on the other missions. I think this is okay
            // Then I need to check for rover availablility


            // I sent the id by reference to the rover to edit
            // Then add them to the map in order to keep track of both simul.
            MissionID = EM->getID();
            if (assignEmergencyMission(RoverID)) {
                EM = MLs.getEmergencyMission();
                MLs.addInExecutionEmergency(
                        EM);// I need to keep the history. I may keep it as a member in the mission itself.
                insertIDPair(MissionID, RoverID);// This is to keep both IDs
            }

        }
        else if (FE->getMissionType() == 'M') {
            int MissionID;
            int RoverID;
            // Don't forget to set the autoP
            MountainousMission *MM = new MountainousMission(FE, getAutoP(), CurrentDay);
            MLs.addMountainousMission(MM);
            MissionID = MM->getID();

            if (assignMountainousMission(RoverID)) {
                MM = MLs.getMountainousMission();
                MLs.addInExecutionMountainous(MM);//
                insertIDPair(MissionID, RoverID);
            }

        } else if (FE->getMissionType() == 'P') {
            int MissionID;
            int RoverID;
            PolarMission *PM = new PolarMission(FE, CurrentDay);
            MLs.addPolarMission(PM);
            MissionID = PM->getID();

            if (assignPolarMission(RoverID)) {
                PM = MLs.getPolarMission();
                MLs.addInExecutionPolar(PM);
                insertIDPair(MissionID, RoverID);
            }
        }
    }
    return true;
}
return false; // This return is somehow meaningless, but I may need it later of checking
}

bool MarsStation::assignEmergencyMission(int& ID)
{

    if(RLs.peekAvailableEmergencyRover())
    { // add to the Emergency if there isn't Mountainous one
        EmergencyRover* ER;
        ER=RLs.getAvailableEmergencyRover();
        RLs.addInMissionEmergencyRover(ER);
        ID= ER->getID();
        return true;
    }
    else if(RLs.peekAvailableMountainousRover())
    {
        MountainousRover* MR;
        MR=RLs.getAvailableMountainousRover();
        RLs.addInMissionMountainousRover(MR);
        ID= MR->getID();
        return true;
    }
    else if (assignPolarMission(ID))
    {
        return true;
    }
    return false;


}

int MarsStation::getAutoP() const
{
    return AutoP;
}

void MarsStation::setAutoP(int autoP) {
    AutoP = autoP;
}

 MissionLists &MarsStation::getMLs()  {
    return MLs;
}

 RoverLists &MarsStation::getRLs()  {
    return RLs;
}

 EventLists &MarsStation::getEVs()  {
    return EVs;
}

bool MarsStation::cancelTodaysMission(int CurrentDay)
{
    if(!EVs.getCancellationEventList().isEmpty())

    {
        while(EVs.peekCancellationEvent()->getEventDay()==CurrentDay ||EVs.peekCancellationEvent()->getEventDay()<CurrentDay)// the smaller than because in the interactive mode we may jump
    {
        CancelEvent* CE;
        CE=EVs.getCancellationEvent();
        int ID=CE->getID();
        MLs.cancelMountainousMission(ID);// The id must of mountainous mission yaay
        return true;
    }
    }
    return false;
}

bool MarsStation::promoteTodaysMission(int CurrentDay)
{
    if (!EVs.getPromotionEventList().isEmpty()) {
        while (EVs.peekPromotionEvent()->getEventDay() == CurrentDay ||EVs.peekPromotionEvent()->getEventDay() < CurrentDay ) {
            PromoteEvent *PE;
            PE = EVs.getPromotionEvent();
            int ID = PE->getID();
            // I  need to cancel the mission and make it Emergency one so I need to get its info first
            MountainousMission *MM = MLs.getWaitingMountainousMissionList().FindID(
                    ID); // constructor in emergency mission to initialize this
            if (MM)// I made it not constant
            {
                EmergencyMission *EM = new EmergencyMission(MLs.getWaitingMountainousMissionList().FindID(ID),
                                                            CurrentDay);
                MLs.cancelMountainousMission(ID);
                MLs.addEmergencyMission(EM);
            }
        }
    }
    return false;
}

bool MarsStation::isCompletedToday(int CurrentDay)
{
    /// now I have is completed function in each missions that takes the current day
    /// I need to loop on the Inexecution List. O.o I need to trace which robots has which mission
    /// Done Mapping the IDs

    /// I can store them in dictionary like
    //// Don't forget to set the completed Day.
    //// And free the robot,
    //// Then check whether it can go to available or go to checkup

    //// Use the FindCompleted method.

//    MountainousMission* MM=;
//// For some reason when I check for MM in the while loop it doesn't see it as null, because it's now updated within the loop
// I'll call it in each step for now.
while(MLs.getInExecutionMountainous().FindCompleted(CurrentDay)||MLs.getInExecutionPolar().FindCompleted(CurrentDay)||MLs.getInExecutionEmergency().FindCompleted(CurrentDay))
{
    if(MLs.getInExecutionPolar().FindCompleted(CurrentDay))
    {

        transferInMissionPolarRover(CompletedPolar(MLs.getInExecutionPolar().FindCompleted(CurrentDay),CurrentDay));
    }


     if(MLs.getInExecutionMountainous().FindCompleted(CurrentDay))
    {

        transferInMissionMountainousRover(CompletedMountainous(MLs.getInExecutionMountainous().FindCompleted(CurrentDay),CurrentDay));
    }


    else if(MLs.getInExecutionEmergency().FindCompleted(CurrentDay))
    {

        transferInMissionEmergencyRover(CompletedEmergency(MLs.getInExecutionEmergency().FindCompleted(CurrentDay),CurrentDay));
    }
//    MountainousMission* MM=MLs.getInExecutionMountainous().FindCompleted(CurrentDay);
return true;
}
return false;

}

void MarsStation::simulate(int CurrentDay)
{
    setCurrentDay(CurrentDay);
    /// The condition when everything return false
    loadFile("../ConfigurationFile.txt");
    // I need to print and also I need to check when the mission is finished to transfer it to the completed
    // and add the rover to the list.
    int i=0;// This is for just experimenting
    PROG_MODE P =UIclass.getProgramMode();
bool assign,cancel,promote,complete=true;

    while(assign||cancel||promote||complete||!MLs.getInExecutionEmergency().isEmpty()||!MLs.getInExecutionPolar().isEmpty()||!MLs.getInExecutionMountainous().isEmpty())
    {
        //// There will be conditions on the modes here
        if (P== (PROG_MODE)0)
        {
            UIclass.waitForUser();
            printInteractiveMode(getCurrentDay()); //// There is error when the interactive is included
            assign=assignTodaysMission(getCurrentDay());
            cancel=cancelTodaysMission(getCurrentDay());
            promote=promoteTodaysMission(getCurrentDay()); // This is working because no promote mission aslan :")
            complete=isCompletedToday( getCurrentDay());
            doneCheckup();

            iterateCurrentDay();
        }
        else if(P== (PROG_MODE)1)
        {
            UIclass.sleep(3);
            printInteractiveMode(getCurrentDay());
            assign=assignTodaysMission(getCurrentDay());
            cancel=cancelTodaysMission(getCurrentDay());
            promote=promoteTodaysMission(getCurrentDay()); // This is working because no promote mission aslan :")
            complete=isCompletedToday( getCurrentDay());
            doneCheckup();
            iterateCurrentDay();
        }
        else
        {
            assign=assignTodaysMission(getCurrentDay());
            cancel=cancelTodaysMission(getCurrentDay());
            promote=promoteTodaysMission(getCurrentDay()); // This is working because no promote mission aslan :")
            complete=isCompletedToday( getCurrentDay());
            doneCheckup();

            iterateCurrentDay();

        }



    }
    writeSampleFile();


}

void MarsStation::insertIDPair(int MissionID, int RoverID)
{
    IDDictionary.insert({MissionID,RoverID});
}

void MarsStation::eraseIDPair(int MissionID)
{
    IDDictionary.erase(MissionID);
}


MountainousRover* MarsStation::CompletedMountainous(MountainousMission *MM,int CurrentDay)
{
    int ID;
    ID=MM->getID();
    /// This is the completed Mission
    MountainousMission* M=new MountainousMission(MM);
    M->setCompletedDay(CurrentDay);
    MLs.deleteInExecutionMountainous(ID);
    MLs.addCompletedMountainousMission(M);
    //// Here I can Delete the pair
    int RoverID=returnRoverID(ID);
    eraseIDPair(ID);
    return RLs.getInMissionMountainousRovers().FindID(RoverID);
    //// Where is the return ??!



}


PolarRover* MarsStation::CompletedPolar(PolarMission *PM,int CurrentDay)
{
    int ID;
    ID=PM->getID();
    /// This is the completed Mission
    PolarMission* M=new PolarMission(PM);
    M->setCompletedDay(CurrentDay);
    MLs.deleteInExecutionPolar(ID);
    MLs.addCompletedPolarMission(M);
    //// Here I can Delete the pair
    int RoverID=returnRoverID(ID);

    eraseIDPair(ID);
    return RLs.getInMissionPolarRovers().FindID(RoverID);

}


EmergencyRover* MarsStation::CompletedEmergency(EmergencyMission *EM,int CurrentDay)
{
    int ID;
    ID=EM->getID();
    /// This is the completed Mission
    EmergencyMission* M=new EmergencyMission(EM);
    M->setCompletedDay(CurrentDay);
    MLs.deleteInExecutionEmergency(ID);
    MLs.addCompletedEmergencyMission(M);
    //// Here I can Delete the pair
    int RoverID=returnRoverID(ID);
    eraseIDPair(ID);
    return RLs.getInMissionEmergencyRovers().FindID(RoverID);
}


bool MarsStation::transferInMissionMountainousRover(MountainousRover *MR)

{


    //// Firstly, I need to delete it from the InMission status
    //// Then, add it either to Checkup or Available by checking the number of missions before duration
    //// This need to be a function there in the rover parent
    ;// This is to add the number of executing mission first.
    // Then I need to check whether to checkup or not
    //// Don't forget that I need to delete the rover from the Inmission List
    // I can make get function in the linked list, this will be better, or just generating another rover.

    if(MR)
    {
        MR->incrementNoOfExecutedMissions();


        int ID=MR->getID();
        if (MR->isCheckUp())
        {


            MountainousRover *NewRover = new MountainousRover(MR);
            NewRover->setStartCheckup(getCurrentDay());
            RLs.addInCheckupMountainousRover(NewRover);// This line extract the node and add to the checkup
            RLs.deleteInMissionMountainousRover(ID); /// I need to delete this

            return true;
        } else {
            MountainousRover *NewRover = new MountainousRover(MR);
            RLs.addAvailableMountainousRover(NewRover);
            RLs.deleteInMissionMountainousRover(ID);
            return true;
        }
    }

    return false;
}


bool MarsStation::transferInMissionPolarRover(PolarRover *PR) {
//    if (PR) {

        int ID = PR->getID();
        PR->incrementNoOfExecutedMissions();// This is to add the number of executing mission first.
        // Then I need to check whether to checkup or not
        //// Don't forget that I need to delete the rover from the Inmission List
        // I can make get function in the linked list, this will be better, or just generating another rover.
/////////


        if (PR->isCheckUp()) {
            PolarRover *NewRover = new PolarRover(PR);
            NewRover->setStartCheckup(getCurrentDay());
            RLs.deleteInMissionPolarRover(ID); /// I need to delete this
            RLs.addInCheckupPolarRover(NewRover);// This line extract the node and add to the checkup

            return true;
        } else {
            PolarRover *NewRover = new PolarRover(PR);
            RLs.deleteInMissionPolarRover(ID);
            RLs.addAvailablePolarRover(NewRover);
            return true;
        }
        //////////
//
//    }
    return false;

}
bool MarsStation::transferInMissionEmergencyRover(EmergencyRover *EM) {
    if (EM) {


//    EM->incrementNoOfExecutedMissions();// This is to add the number of executing mission first.
        // Then I need to check whether to checkup or not
        //// Don't forget that I need to delete the rover from the Inmission List
        // I can make get function in the linked list, this will be better, or just generating another rover.
        int ID = EM->getID();
        EM->incrementNoOfExecutedMissions();// This is to add the number of executing mission first.
        // Then I need to check whether to checkup or not
        //// Don't forget that I need to delete the rover from the Inmission List
        // I can make get function in the linked list, this will be better, or just generating another rover.
/////////


        if (EM->isCheckUp()) {
            EmergencyRover *NewRover = new EmergencyRover(EM);
            NewRover->setStartCheckup(getCurrentDay());
            RLs.addInCheckupEmergencyRover(NewRover);// This line extract the node and add to the checkup
            RLs.deleteInMissionEmergencyRover(ID); /// I need to delete this

            return true;
        } else {
            EmergencyRover *NewRover = new EmergencyRover(EM);
            RLs.addAvailableEmergencyRover(NewRover);
            RLs.deleteInMissionEmergencyRover(ID);
            return true;
        }
    }
    return false;
}

int MarsStation::returnRoverID(int MissionID)
{
    return this->IDDictionary[MissionID];
}


void MarsStation::AvailableRoversIDs(vector<int> &AvailableMountainousRoversIDs, vector<int> &AvailablePolarRoversIDs,
                                     vector<int> &AvailableEmergencyRoversIDs, LinkedQueue<MountainousRover *> MRQueue,
                                     LinkedQueue<PolarRover *> PRQueue, LinkedQueue<EmergencyRover *> ERQueue) {
    /// So we will simply dequeue and then get the IDs
    //// This would be better here if I implemented it by linked list maybe. I mean available rover. But it's just good for this function purpose not generally.
    // The IDs is return in the form of vector and I will pop the IDs there in the print function
    bool BoolMountainousID;
    MountainousRover* M;
    BoolMountainousID=MRQueue.dequeue(M);
    while(BoolMountainousID)
    {
        AvailableMountainousRoversIDs.push_back(M->getID());
        BoolMountainousID=MRQueue.dequeue(M);
    }
    bool BoolPolarID;
    PolarRover* P;
    BoolPolarID=PRQueue.dequeue(P);
    while(BoolPolarID)
    {
        AvailablePolarRoversIDs.push_back(P->getID());
        BoolPolarID=PRQueue.dequeue(P);
    }
    bool BoolEmergencyID;
    EmergencyRover* E;
    BoolEmergencyID=ERQueue.dequeue(E);
    while(BoolEmergencyID)
    {
        AvailableEmergencyRoversIDs.push_back(E->getID());
        BoolEmergencyID=ERQueue.dequeue(E);
    }
    ///// So this vector is used in order to get all IDs


}

void MarsStation::WaitingMissionsIDs(vector<int> &AvailableMountainousMissionsIDs, vector<int> &AvailablePolarMissionsIDs,
                                vector<int> &AvailableEmergencyMissionsIDs, LinkedListMissions<MountainousMission *> MMList,
                                LinkedQueue<PolarMission *> PMQueue, MaxHeap<EmergencyMission *> EMHeap)
{
//    MountainousMission* M;
    int ID;
    while(MMList.getHead())
    {
        ID=MMList.getHead()->getItem()->getID();
        AvailableMountainousMissionsIDs.push_back(ID);
        MMList.DeleteFirst();
    }

    bool BoolPolarID;
    PolarMission* P;
    BoolPolarID=PMQueue.dequeue(P);
    while(BoolPolarID)
    {
        AvailablePolarMissionsIDs.push_back(P->getID());
        BoolPolarID=PMQueue.dequeue(P);
    }

    EmergencyMission* E;
    E=EMHeap.extractMax();
    while(E)
    {
        AvailableEmergencyMissionsIDs.push_back(E->getID());
        delete E;
        E=EMHeap.extractMax();
    }

}

void MarsStation::CompletedMissionsIDs(vector<int> &CompletedMountainousMissionsIDs, vector<int> &CompletedPolarMissionsIDs,
                                  vector<int> &CompletedEmergencyMissionsIDs, LinkedListMissions<MountainousMission *>* MMList,LinkedListMissions<PolarMission *>* PMList, LinkedListMissions<EmergencyMission *>* EMList)
{




    int ID;
    while(MMList->getHead())
    {
        ID=MMList->getHead()->getItem()->getID();
        CompletedMountainousMissionsIDs.push_back(ID);
        MMList->DeleteFirst();
    }


    while(PMList->getHead())
    {
        ID=PMList->getHead()->getItem()->getID();
        CompletedPolarMissionsIDs.push_back(ID);
        PMList->DeleteFirst();
    }


    while(EMList->getHead())
    {
        ID=EMList->getHead()->getItem()->getID();
        CompletedEmergencyMissionsIDs.push_back(ID);
        EMList->DeleteFirst();
    }
}

//// This function prints the missions but i need to be adjusted as it gets the Completed List and delete it.
//// or at least I need to extract information later.

void MarsStation::InExecutionMissionsIDs(vector<int> &InExecutionMountainousMissionsIDs,
                                         vector<int> &InExecutionPolarMissionsIDs,
                                         vector<int> &InExecutionEmergencyMissionsIDs,
                                         LinkedListMissions<MountainousMission *>* MMList, LinkedListMissions<PolarMission *>* PMList,

                                         LinkedListMissions<EmergencyMission *>* EMList)
{
    int ID;
    while(MMList->getHead())
    {
        ID=MMList->getHead()->getItem()->getID();
        InExecutionMountainousMissionsIDs.push_back(ID);
        MMList->DeleteFirst();
    }


    while(PMList->getHead())
    {
        ID=PMList->getHead()->getItem()->getID();
        InExecutionPolarMissionsIDs.push_back(ID);
        PMList->DeleteFirst();
    }


    while(EMList->getHead())
    {
        ID=EMList->getHead()->getItem()->getID();
        InExecutionEmergencyMissionsIDs.push_back(ID);
        EMList->DeleteFirst();
    }
}


/*
void MarsStation::printInteractiveMode(int CurrentDay) {
    ////// Avaialble rovers


    AvailableRoversIDs(AvailableMountainousRoversIDs, AvailablePolarRoversIDs,  AvailableEmergencyRoversIDs, RLs.getAvailableMountainousRovers(),  RLs.getAvailablePolarRovers(),  RLs.getAvailableEmergencyRovers());


    UIclass.addToAvailableRoversString();
    for (auto i = AvailableMountainousRoversIDs.begin(); i != AvailableMountainousRoversIDs.end(); ++i)
    {UIclass.addToMountainousString(*i);
//        AvailableMountainousRoversIDs.push_back(*i);
    }

    for (auto i = AvailablePolarRoversIDs.begin(); i != AvailablePolarRoversIDs.end(); ++i)
    {UIclass.addToPolarString(*i);
//        AvailablePolarRoversIDs.push_back(*i);
    }

    for (auto i = AvailableEmergencyRoversIDs.begin(); i != AvailableEmergencyRoversIDs.end(); ++i)
    {UIclass.addToEmergencyString(*i);
//        AvailableEmergencyRoversIDs.push_back(*i);
    }


////// Waiting Missions





    WaitingMissionsIDs( AvailableMountainousMissionsIDs,  AvailablePolarMissionsIDs, AvailableEmergencyMissionsIDs, MLs.getWaitingMountainousMissionList(),MLs.getWaitingPolarMissionQueue(),MLs.getWaitingEmergencyMissionHeap());

    UIclass.addToWaitingString();

    for (auto i = AvailableMountainousMissionsIDs.begin(); i != AvailableMountainousMissionsIDs.end(); ++i)
    {UIclass.addToMountainousString(*i);}

    for (auto i = AvailablePolarMissionsIDs.begin(); i != AvailablePolarMissionsIDs.end(); ++i)
    {UIclass.addToPolarString(*i);}

    for (auto i = AvailableEmergencyMissionsIDs.begin(); i != AvailableEmergencyMissionsIDs.end(); ++i)
    {UIclass.addToEmergencyString(*i);}


////// Completed Missions


    LinkedListMissions<MountainousMission *>* MMList=&MLs.getCompletedMountainous();
    LinkedListMissions<PolarMission *>* PMList=&MLs.getCompletedPolar();
    LinkedListMissions<EmergencyMission *>* EMList=&MLs.getCompletedEmergency();
//    LinkedListMissions<PolarMission *> PMList=MLs.getCompletedPolar();
//    LinkedListMissions<EmergencyMission *> EMList=MLs.getCompletedEmergency();

//    LinkedListMissions<MountainousMission*> ML=
    CompletedMissionsIDs(CompletedMountainousMissionsIDs, CompletedPolarMissionsIDs,
                         CompletedEmergencyMissionsIDs,MMList ,PMList,EMList);

    UIclass.addToCompletedString();
    for (auto i = CompletedMountainousMissionsIDs.begin(); i != CompletedMountainousMissionsIDs.end(); ++i)
    {UIclass.addToMountainousString(*i);}

    for (auto i = CompletedPolarMissionsIDs.begin(); i != CompletedPolarMissionsIDs.end(); ++i)
    {UIclass.addToPolarString(*i);}

    for (auto i = CompletedEmergencyMissionsIDs.begin(); i != CompletedEmergencyMissionsIDs.end(); ++i)
    {UIclass.addToEmergencyString(*i);}



///// InExecution Missions


    vector<int> InExecutionMountainousMissionsIDs;
    vector<int> InExecutionEmergencyMissionsIDs;
    vector<int> InExecutionPolarMissionsIDs;

//// This is totally wrong way aslan.
    LinkedListMissions<MountainousMission *>* MMMList=&MLs.getInExecutionMountainous();
    LinkedListMissions<PolarMission *>* PPMList=&MLs.getInExecutionPolar();
    LinkedListMissions<EmergencyMission *>* EEMList=&MLs.getInExecutionEmergency();

    InExecutionMissionsIDs(InExecutionMountainousMissionsIDs,
                           InExecutionPolarMissionsIDs,
                           InExecutionEmergencyMissionsIDs, MMMList,PPMList,EEMList);


    UIclass.addToInExecutionString();
    for (auto i = InExecutionMountainousMissionsIDs.begin(); i != InExecutionMountainousMissionsIDs.end(); ++i)
    {UIclass.addToMountainousString(*i);}

    for (auto i = InExecutionEmergencyMissionsIDs.begin(); i != InExecutionEmergencyMissionsIDs.end(); ++i)
    {UIclass.addToPolarString(*i);}

    for (auto i = InExecutionPolarMissionsIDs.begin(); i != InExecutionPolarMissionsIDs.end(); ++i)
    {UIclass.addToEmergencyString(*i);}





    UIclass.printCurrentDay(getCurrentDay());



}
*/
void MarsStation::printInteractiveMode(int CurrentDay)
{

    vector<int>AvailableMountainousRoversIDs= RLs.getAvailableMountainousRoversIDs();
    vector<int> AvailablePolarRoversIDs=RLs.getAvailablePolarRoversIDs();
    vector<int> AvailableEmergencyRoversIDs=RLs.getAvailableEmergencyRoversIDs();
    UIclass.addToAvailableRoversString();
    for (auto i = AvailableMountainousRoversIDs.begin(); i != AvailableMountainousRoversIDs.end(); ++i)
    {UIclass.addToMountainousString(*i);
//        AvailableMountainousRoversIDs.push_back(*i);
    }

    for (auto i = AvailablePolarRoversIDs.begin(); i != AvailablePolarRoversIDs.end(); ++i)
    {UIclass.addToPolarString(*i);
//        AvailablePolarRoversIDs.push_back(*i);
    }

    for (auto i = AvailableEmergencyRoversIDs.begin(); i != AvailableEmergencyRoversIDs.end(); ++i)
    {UIclass.addToEmergencyString(*i);
//        AvailableEmergencyRoversIDs.push_back(*i);
    }








    vector<int> AvailablePolarMissionsIDs=MLs.getAvailablePolarMissionsIDs();

    vector<int> AvailableEmergencyMissionsIDs=MLs.getAvailableEmergencyMissionsIDs();

    vector<int> AvailableMountainousMissionsIDs=MLs.getAvailableMountainousMissionsIDs();

    UIclass.addToWaitingString();
    for (auto i = AvailableMountainousMissionsIDs.begin(); i != AvailableMountainousMissionsIDs.end(); ++i)
    {UIclass.addToMountainousString(*i);}

    for (auto i = AvailablePolarMissionsIDs.begin(); i != AvailablePolarMissionsIDs.end(); ++i)
    {UIclass.addToPolarString(*i);}

    for (auto i = AvailableEmergencyMissionsIDs.begin(); i != AvailableEmergencyMissionsIDs.end(); ++i)
    {UIclass.addToEmergencyString(*i);}





    UIclass.addToCompletedString();
    vector<int> CompletedMountainousMissionsIDs=MLs.getCompletedMountainousMissionsIDs();

    vector<int> CompletedPolarMissionsIDs=MLs.getCompletedPolarMissionsIDs();

    vector<int> CompletedEmergencyMissionsIDs=MLs.getCompletedEmergencyMissionsIDs();

    for (auto i = CompletedMountainousMissionsIDs.begin(); i != CompletedMountainousMissionsIDs.end(); ++i)
    {UIclass.addToMountainousString(*i);}

    for (auto i = CompletedPolarMissionsIDs.begin(); i != CompletedPolarMissionsIDs.end(); ++i)
    {UIclass.addToPolarString(*i);}

    for (auto i = CompletedEmergencyMissionsIDs.begin(); i != CompletedEmergencyMissionsIDs.end(); ++i)
    {UIclass.addToEmergencyString(*i);}




    UIclass.addToInExecutionString();
    vector< int> InExecutionPolarMissionsIDs=MLs.getInExecutionPolarMissionhistory();

    vector< int> InExecutionEmergencyMissionsIDs=MLs.getInExecutionEmergencyMissionhistory();

    vector< int> InExecutionMountainousMissionsIDs=MLs.getInExecutionMountainousMissionhistory();

    for (auto i = InExecutionMountainousMissionsIDs.begin(); i != InExecutionMountainousMissionsIDs.end(); ++i)
    {UIclass.addToMountainousString(*i);}

    for (auto i = InExecutionEmergencyMissionsIDs.begin(); i != InExecutionEmergencyMissionsIDs.end(); ++i)
    {UIclass.addToPolarString(*i);}

    for (auto i = InExecutionPolarMissionsIDs.begin(); i != InExecutionPolarMissionsIDs.end(); ++i)
    {UIclass.addToEmergencyString(*i);}
    UIclass.printCurrentDay(getCurrentDay());


}
bool MarsStation::doneCheckup()
{

    /// Wokr on Find doneCheckup function. Like Finde Completed



    while(RLs.getInCheckupMountainousRovers().FindCheckUp(getCurrentDay())||
    RLs.getInCheckupPolarRovers().FindCheckUp(getCurrentDay())||RLs.getInCheckupEmergencyRovers().FindCheckUp(getCurrentDay()))
{
    if(RLs.getInCheckupPolarRovers().FindCheckUp(getCurrentDay()))
    {
        //// So what to do?
        // firstly get it from the list
        PolarRover* PR=RLs.getInCheckupPolarRovers().FindCheckUp(getCurrentDay());
        int ID = PR->getID();
        PolarRover *NewRover = new PolarRover(PR);
        NewRover->setStartCheckup(0);// Reset the checkup
        RLs.deleteInCheckupPolarRover(ID); /// I need to delete this
        // Secondly create another one and make it available

        RLs.addAvailablePolarRover(NewRover);
//        transferInMissionPolarRover(CompletedPolar(RLs.getInExecutionPolar().FindCompleted(CurrentDay),CurrentDay));
    }
     if(RLs.getInCheckupMountainousRovers().FindCheckUp(getCurrentDay()))
    {
        MountainousRover* PR=RLs.getInCheckupMountainousRovers().FindCheckUp(getCurrentDay());
        int ID = PR->getID();
        MountainousRover *NewRover = new MountainousRover(PR);
        NewRover->setStartCheckup(0);// Reset the checkup
        RLs.deleteInCheckupMountainousRover(ID); /// I need to delete this
        // Secondly create another one and make it available

        RLs.addAvailableMountainousRover(NewRover);



//        transferInMissionMountainousRover(CompletedMountainous(RLs.getInExecutionMountainous().FindCompleted(CurrentDay),CurrentDay));
    }
    else if(RLs.getInCheckupEmergencyRovers().FindCheckUp(getCurrentDay()))
    {
        EmergencyRover* PR=RLs.getInCheckupEmergencyRovers().FindCheckUp(getCurrentDay());
        int ID = PR->getID();
        EmergencyRover *NewRover = new EmergencyRover(PR);
        NewRover->setStartCheckup(0);// Reset the checkup
        RLs.deleteInCheckupEmergencyRover(ID); /// I need to delete this
        // Secondly create another one and make it available

        RLs.addAvailableEmergencyRover(NewRover);

//        transferInMissionEmergencyRover(CompletedEmergency(RLs.getInExecutionEmergency().FindCompleted(CurrentDay),CurrentDay));
    }
//    MountainousMission* MM=MLs.getInExecutionMountainous().FindCompleted(CurrentDay);


    }
    return true;


    //// This function should loop over the all checkup list and check to get them to available

}

int MarsStation::getCurrentDay() const {
    return CurrentDay;
}

void MarsStation::setCurrentDay(int currentDay) {
    CurrentDay = currentDay;
}

int MarsStation::iterateCurrentDay() {
    setCurrentDay(getCurrentDay()+1);
}




void MarsStation::writeSampleFile()
{


    vector<int> MissionsCompletedHistory=MLs.getMissionsCompletedHistory();

    ofstream myfile;
    myfile.open ("../SampleOutput.txt");
    myfile << "        CD        ID        FD        WD        ED.\n";

    int FLag=0;
    for (auto i = MissionsCompletedHistory.begin(); i != MissionsCompletedHistory.end(); ++i)
    {
        FLag++;
        myfile << "        "<<*i;
        if (FLag==5)
        {
            myfile << "\n";
            FLag=0;
        }

    }
    //// At the end they're all available
    vector<int>AvailableMountainousRoversIDs= RLs.getAvailableMountainousRoversIDs();
    vector<int> AvailablePolarRoversIDs=RLs.getAvailablePolarRoversIDs();
    vector<int> AvailableEmergencyRoversIDs=RLs.getAvailableEmergencyRoversIDs();


    //// At the End all missions are completed
    vector<int> CompletedMountainousMissionsIDs=MLs.getCompletedMountainousMissionsIDs();

    vector<int> CompletedPolarMissionsIDs=MLs.getCompletedPolarMissionsIDs();

    vector<int> CompletedEmergencyMissionsIDs=MLs.getCompletedEmergencyMissionsIDs();


    myfile << "Missions:    ";
    myfile << (CompletedMountainousMissionsIDs.size()+CompletedPolarMissionsIDs.size()+CompletedEmergencyMissionsIDs.size());
    myfile << "    [M: ";
    myfile << CompletedMountainousMissionsIDs.size();
    myfile << ", P: ";
    myfile << CompletedPolarMissionsIDs.size();
    myfile << ", E: ";
    myfile << CompletedEmergencyMissionsIDs.size();
    myfile << " ] \n ";


    myfile << "Rovers: ";
    myfile << (AvailableMountainousRoversIDs.size()+AvailablePolarRoversIDs.size()+AvailableEmergencyRoversIDs.size());
    myfile << "    [M: ";
    myfile << AvailableMountainousRoversIDs.size();
    myfile << ", P: ";
    myfile << AvailablePolarRoversIDs.size();
    myfile << ", E: ";
    myfile << AvailableEmergencyRoversIDs.size();
    myfile << " ] \n ";


    myfile << "Avg Wait="; // ^_^ Sorry
    myfile << 0;
    myfile << "Avg Exec=";
    myfile << 100;
    myfile << "\nAvg Exec=";
    myfile << "0 %";

    myfile.close();





}






//
// Created by raspberry on 2020-11-30.
//

#include "MissionLists.h"


MissionLists::MissionLists()
{
    setNoOfCompletedEmergency(0);
setNoOfCompletedMountainous(0);
setNoOfCompletedPolar(0);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
EmergencyMission *MissionLists::getEmergencyMission() {
    EmergencyMission *Em = WaitingEmergencyMissionHeap.extractMax();
    int ID=Em->getID();
    AvailableEmergencyMissionsIDs.erase(std::remove(AvailableEmergencyMissionsIDs.begin(), AvailableEmergencyMissionsIDs.end(), ID), AvailableEmergencyMissionsIDs.end());
//    InExecutionEmergencyMissionhistory.push_back(Em->getID());
    return Em;
}
const MaxHeap<EmergencyMission*> MissionLists::getWaitingEmergencyMissionHeap()const
{
    return WaitingEmergencyMissionHeap;
}
void MissionLists::addEmergencyMission(EmergencyMission *EMission)
{
    WaitingEmergencyMissionHeap.insertItem(EMission);
    AvailableEmergencyMissionsIDs.push_back(EMission->getID());

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 LinkedQueue<PolarMission*> MissionLists::getWaitingPolarMissionQueue()
{
    return WaitingPolarMissionQueue;
}
void MissionLists::addPolarMission(PolarMission *PMission)
{

    WaitingPolarMissionQueue.enqueue(PMission);
    AvailablePolarMissionsIDs.push_back(PMission->getID());

}
PolarMission *MissionLists::getPolarMission() {
    PolarMission * P;

    WaitingPolarMissionQueue.dequeue(P);
    int ID=P->getID();
    AvailablePolarMissionsIDs.erase(std::remove(AvailablePolarMissionsIDs.begin(), AvailablePolarMissionsIDs.end(), ID), AvailablePolarMissionsIDs.end());
//    InExecutionPolarMissionhistory.push_back(P->getID());

    return P;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 LinkedListMissions<MountainousMission*> MissionLists::getWaitingMountainousMissionList()
{

    return WaitingMountainousMissionList;
}


void MissionLists::addMountainousMission(MountainousMission *MMission)
{

    AvailableMountainousMissionsIDs.push_back(MMission->getID());
    WaitingMountainousMissionList.InsertBeg(MMission);
}


MountainousMission *MissionLists::getMountainousMission() {

    MountainousMission * M=WaitingMountainousMissionList.getHead()->getItem();
    int ID= M->getID();
    AvailableMountainousMissionsIDs.erase(std::remove(AvailableMountainousMissionsIDs.begin(), AvailableMountainousMissionsIDs.end(), ID), AvailableMountainousMissionsIDs.end());
    WaitingMountainousMissionList.DeleteFirst();
//    InExecutionMountainousMissionhistory.push_back(M->getID()); // It's there in addExecution

    return M;
}


void MissionLists::cancelMountainousMission(int ID)
{
    AvailableMountainousMissionsIDs.erase(std::remove(AvailableMountainousMissionsIDs.begin(), AvailableMountainousMissionsIDs.end(), ID), AvailableMountainousMissionsIDs.end());

    WaitingMountainousMissionList.DeleteNode(ID);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





MissionLists::~MissionLists() {

}

int MissionLists::getNoOfCompletedPolar() const {
    return CompletedPolar.getCount();
}

int MissionLists::getNoOfCompletedEmergency()  {
    return CompletedEmergency.getCount();
}

int MissionLists::getNoOfCompletedMountainous() const {
    return CompletedMountainous.getCount();
}

void MissionLists::setNoOfCompletedPolar(int noOfCompletedPolar) {
    NoOfCompletedPolar = noOfCompletedPolar;
}

void MissionLists::setNoOfCompletedEmergency(int noOfCompletedEmergency) {
    NoOfCompletedEmergency = noOfCompletedEmergency;
}

void MissionLists::setNoOfCompletedMountainous(int noOfCompletedMountainous) {
    NoOfCompletedMountainous = noOfCompletedMountainous;
}



 LinkedListMissions<MountainousMission *> &MissionLists::getInExecutionMountainous()  {
    return InExecutionMountainous;
}

 LinkedListMissions<EmergencyMission *> &MissionLists::getInExecutionEmergency()  {
    return InExecutionEmergency;
}

 LinkedListMissions<PolarMission *> &MissionLists::getInExecutionPolar()  {
    return InExecutionPolar;
}




void MissionLists::addInExecutionEmergency(EmergencyMission *EMission)
{

    InExecutionEmergency.InsertBeg(EMission);
    InExecutionEmergencyMissionhistory.push_back(EMission->getID()); ///// This could be repeated

}

void MissionLists::deleteInExecutionEmergency(int ID)
{
    InExecutionEmergencyMissionhistory.erase(std::remove(InExecutionEmergencyMissionhistory.begin(), InExecutionEmergencyMissionhistory.end(), ID), InExecutionEmergencyMissionhistory.end());

    InExecutionEmergency.DeleteNode(ID);
}

void MissionLists::addInExecutionPolar(PolarMission *EMission)
{

    InExecutionPolar.InsertBeg(EMission);
    InExecutionPolarMissionhistory.push_back(EMission->getID());

}

void MissionLists::deleteInExecutionPolar(int ID)
{
    InExecutionPolar.DeleteNode(ID);
    InExecutionPolarMissionhistory.erase(std::remove(InExecutionPolarMissionhistory.begin(), InExecutionPolarMissionhistory.end(), ID), InExecutionPolarMissionhistory.end());

}

void MissionLists::addInExecutionMountainous(MountainousMission *EMission)
{
    InExecutionMountainousMissionhistory.push_back(EMission->getID());

    InExecutionMountainous.InsertBeg(EMission);

}

void MissionLists::deleteInExecutionMountainous(int ID)
{
    InExecutionMountainous.DeleteNode(ID);
    InExecutionEmergencyMissionhistory.erase(std::remove(InExecutionEmergencyMissionhistory.begin(), InExecutionEmergencyMissionhistory.end(), ID), InExecutionEmergencyMissionhistory.end());

}



int MissionLists::getNoOfWaitingEmergencyMission() const {
    return WaitingEmergencyMissionHeap.getSize();
}

int MissionLists::getNoOfWaitingPolarMission() const {
    return WaitingPolarMissionQueue.getSize();
}

int MissionLists::getNoOfWaitingMountainousMission() const {
    return WaitingMountainousMissionList.getCount();
}

int MissionLists::getNoOfInExecutionMountainous() const {
    return InExecutionMountainous.getCount();
}

int MissionLists::getNoOfInExecutionEmergency() const {
    return InExecutionEmergency.getCount();
}

int MissionLists::getNoOfInExecutionPolar() const {
    return InExecutionPolar.getCount();
}



 LinkedListMissions<MountainousMission *> &MissionLists::getCompletedMountainous()   {
    return CompletedMountainous;
}

 LinkedListMissions<EmergencyMission *> &MissionLists::getCompletedEmergency()  {
    return CompletedEmergency;
}

  LinkedListMissions<PolarMission *> &MissionLists::getCompletedPolar()
  {
    return CompletedPolar;
}

void MissionLists::addCompletedEmergencyMission(EmergencyMission *EMission)
{
    int ID=EMission->getID();
    CompletedEmergencyMissionsIDs.push_back(EMission->getID());
//    InExecutionEmergencyMissionhistory.erase(std::remove(InExecutionEmergencyMissionhistory.begin(), InExecutionEmergencyMissionhistory.end(), ID), InExecutionEmergencyMissionhistory.end());

    MissionsCompletedHistory.push_back(EMission->getCompletedDay());
    MissionsCompletedHistory.push_back(EMission->getID());
    MissionsCompletedHistory.push_back(EMission->getFormulatedDay());
    MissionsCompletedHistory.push_back(EMission->getWaitingDays());
    MissionsCompletedHistory.push_back(EMission->getED());
    CompletedEmergency.InsertBeg(EMission);

}

void MissionLists::addCompletedPolarMission(PolarMission *PMission)
{
    CompletedPolarMissionsIDs.push_back(PMission->getID());
    MissionsCompletedHistory.push_back(PMission->getCompletedDay());
    MissionsCompletedHistory.push_back(PMission->getID());
    MissionsCompletedHistory.push_back(PMission->getFormulatedDay());
    MissionsCompletedHistory.push_back(PMission->getWaitingDays());
    MissionsCompletedHistory.push_back(PMission->getED());
    CompletedPolar.InsertBeg(PMission);

}

void MissionLists::addCompletedMountainousMission(MountainousMission *MMission)
{
    int ID=MMission->getID();
    CompletedMountainousMissionsIDs.push_back(MMission->getID());
    InExecutionMountainousMissionhistory.erase(std::remove(InExecutionMountainousMissionhistory.begin(), InExecutionMountainousMissionhistory.end(), ID), InExecutionMountainousMissionhistory.end());
    MissionsCompletedHistory.push_back(MMission->getCompletedDay());
    MissionsCompletedHistory.push_back(MMission->getID());
    MissionsCompletedHistory.push_back(MMission->getFormulatedDay());
    MissionsCompletedHistory.push_back(MMission->getWaitingDays());
    MissionsCompletedHistory.push_back(MMission->getED());
    CompletedMountainous.InsertBeg(MMission);

}

const vector<int> &MissionLists::getAvailableMountainousMissionsIDs() const {
    return AvailableMountainousMissionsIDs;
}

void MissionLists::setAvailableMountainousMissionsIDs(const vector<int> &availableMountainousMissionsIDs) {
    AvailableMountainousMissionsIDs = availableMountainousMissionsIDs;
}

const vector<int> &MissionLists::getAvailablePolarMissionsIDs() const {
    return AvailablePolarMissionsIDs;
}

void MissionLists::setAvailablePolarMissionsIDs(const vector<int> &availablePolarMissionsIDs) {
    AvailablePolarMissionsIDs = availablePolarMissionsIDs;
}

const vector<int> &MissionLists::getAvailableEmergencyMissionsIDs() const {
    return AvailableEmergencyMissionsIDs;
}

void MissionLists::setAvailableEmergencyMissionsIDs(const vector<int> &availableEmergencyMissionsIDs) {
    AvailableEmergencyMissionsIDs = availableEmergencyMissionsIDs;
}

const vector<int> &MissionLists::getCompletedMountainousMissionsIDs() const {
    return CompletedMountainousMissionsIDs;
}

void MissionLists::setCompletedMountainousMissionsIDs(const vector<int> &completedMountainousMissionsIDs) {
    CompletedMountainousMissionsIDs = completedMountainousMissionsIDs;
}

const vector<int> &MissionLists::getCompletedPolarMissionsIDs() const {
    return CompletedPolarMissionsIDs;
}

void MissionLists::setCompletedPolarMissionsIDs(const vector<int> &completedPolarMissionsIDs) {
    CompletedPolarMissionsIDs = completedPolarMissionsIDs;
}

const vector<int> &MissionLists::getCompletedEmergencyMissionsIDs() const {
    return CompletedEmergencyMissionsIDs;
}

void MissionLists::setCompletedEmergencyMissionsIDs(const vector<int> &completedEmergencyMissionsIDs) {
    CompletedEmergencyMissionsIDs = completedEmergencyMissionsIDs;
}

const vector<int> &MissionLists::getInExecutionPolarMissionhistory() const {
    return InExecutionPolarMissionhistory;
}

void MissionLists::setInExecutionPolarMissionhistory(const vector<int> &inExecutionPolarMissionhistory) {
    InExecutionPolarMissionhistory = inExecutionPolarMissionhistory;
}

const vector<int> &MissionLists::getInExecutionEmergencyMissionhistory() const {
    return InExecutionEmergencyMissionhistory;
}

void MissionLists::setInExecutionEmergencyMissionhistory(const vector<int> &inExecutionEmergencyMissionhistory) {
    InExecutionEmergencyMissionhistory = inExecutionEmergencyMissionhistory;
}

const vector<int> &MissionLists::getInExecutionMountainousMissionhistory() const {
    return InExecutionMountainousMissionhistory;
}

void MissionLists::setInExecutionMountainousMissionhistory(const vector<int> &inExecutionMountainousMissionhistory) {
    InExecutionMountainousMissionhistory = inExecutionMountainousMissionhistory;
}

const vector<int> &MissionLists::getMissionsCompletedHistory() const {
    return MissionsCompletedHistory;
}

void MissionLists::setMissionsCompletedHistory(const vector<int> &missionsCompletedHistory) {
    MissionsCompletedHistory = missionsCompletedHistory;
}




